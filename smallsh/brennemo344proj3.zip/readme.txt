Compile with the following command:

gcc -o smallsh smallsh.c 